﻿print("Hello World!")
